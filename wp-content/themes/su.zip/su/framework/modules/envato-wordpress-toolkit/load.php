<?php

if (qode_envato_wordpress_toolkit_installed()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/envato-wordpress-toolkit/envato-wordpress-toolkit-config.php';
}