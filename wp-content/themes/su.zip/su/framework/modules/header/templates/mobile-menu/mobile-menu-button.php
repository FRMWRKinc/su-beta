<?php if(qode_is_main_menu_set()) { ?>
	<div class="mobile_menu_button">
		<span>
			<?php echo qode_get_mobile_menu_icon_html(); ?>
		</span>
	</div>
<?php } ?>