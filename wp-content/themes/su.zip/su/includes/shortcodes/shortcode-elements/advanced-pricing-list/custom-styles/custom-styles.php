<?php

if(!function_exists('qode_advanced_pricing_list_styles')) {

    function qode_advanced_pricing_list_styles() {


    }

    add_action('qode_style_dynamic', 'qode_advanced_pricing_list_styles');
}
