<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/blog-carousel-titled/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/blog-carousel-titled/blog-carousel-titled.php';