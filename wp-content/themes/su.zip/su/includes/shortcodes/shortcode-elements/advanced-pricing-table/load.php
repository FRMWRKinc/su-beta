<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-table/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-table/advanced-pricing-table.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-table/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-table/custom-styles/custom-styles.php';