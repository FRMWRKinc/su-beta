<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/multi-device-showcase/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/multi-device-showcase/multi-device-showcase.php';
