<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/horizontal-timeline/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/horizontal-timeline/horizontal-timeline.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/horizontal-timeline/horizontal-timeline-item.php';