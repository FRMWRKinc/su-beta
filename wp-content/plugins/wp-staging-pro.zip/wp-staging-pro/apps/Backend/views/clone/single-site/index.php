<ul id="wpstg-steps">
    <li class="wpstg-current-step">
        <span class="wpstg-step-num">1</span>
        <?php echo __("Overview", "wpstg")?>
    </li>
    <li>
        <span class="wpstg-step-num">2</span>
        <?php echo __("Scanning", "wpstg")?>
    </li>
    <li>
        <span class="wpstg-step-num">3</span>
        <?php echo __("Cloning", "wpstg")?>
    </li>
    <li>
        <span id="wpstg-loader" style="display:none;"></span>
    </li>
</ul>

<div id="wpstg-workflow"></div>