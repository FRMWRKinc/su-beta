<span class="wpstg-notice-alert" style="margin-top:20px;">
    <?php echo sprintf(__("This is your staging site. Go to your live site to use that function.", "wpstg"), 
            admin_url() . 'admin.php?page=wpstg_clone')?>
</span>