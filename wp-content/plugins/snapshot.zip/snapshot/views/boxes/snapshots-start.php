<div class="wpmud-box-title buttons">

	<h3>Snapshots</h3>

</div><!-- end .wpmud-box-title -->

<div class="wpmud-box-content">

	<div class="row">

		<p><img class="hero-circle"><br>The performance test didn't return any results. This probably means you're on a local website (which we can't scan) or something went wrong trying to access WPMU DEV. Try again and if this error continues to appear please open a ticket with our support heroes</p>

		<a href="http://snapshot.wpmudev.dev/wp-admin/admin.php?page=wphb&amp;run=true&amp;type=performance&amp;_wpnonce=0360bdece0#wphb-box-dashboard-performance-running-test" class="button button-blue">Create Snapshot</a>

	</div>

</div><!-- end .wpmud-box-content -->