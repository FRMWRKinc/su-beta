=== Screen Options and Help Show Customize ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp/please-donation/?utm_source=wporg&utm_medium=donate&utm_content=sohc&utm_campaign=1_3_3
Tags: admin, dashboard, menu, options, option, help, tabs, role, user, screen options, media, link, pages, page, posts, post
Requires at least: 3.7.3
Tested up to: 4.2.2
Stable tag: 1.3.3
License: GPL2

Customization of the Screen options and Help.

== Description ==

Set display options and getting help, and set the default page for almost all.
Further change the display for each user role.
With Multisite Supported.

== Installation ==

1. Upload the entire post-list-view-custom folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will find 'Screen Options Customize' menu in your WordPress admin panel on 'Settings'.

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

1. Settings Interface

== Changelog ==

= 1.3.3 =
* Security enhancement: Escape to add_query_arg/remove_query_arg.

= 1.3.2 =
* Fixed: Get the current user group.

= 1.3.1 =
* Fixed: Activate the WooCommerce check.

= 1.3 =
* Added: Hide to Screen Options of Custom Post type and Custom Taxonomies.
* Added: Setup to minimum role for plugin working user role.
* Added: Support to WooCommerce.
* Updated: Improve ease of use.

= 1.2.7 =
* Added: The translation for turkey.

= 1.2.6 =
* Updated: Existence check of Link Manager.
* Updated: Compatible WP3.8.

= 1.2.5 =
* Support SSL.
* Added to Custom Taxonomies.
* Added to Generals on Multisite.

= 1.2.4.2 =
* Added a confirmation of Nonce field.
* Changed items of Add user.

= 1.2.4.1 =
* Change the mouse cursor.
* Change some translations.

= 1.2.4 =
Added a custom post types.

= 1.2.3 =
Change notation for donation.
Changed so that it is easy to look at the fields.

= 1.2.2 =
Link mistake.

= 1.2.1 =
Fixed a bug that does not work the single site.
Only when the multisite, enable to select my-sites.

= 1.2 =
I support multisite.

= 1.1 =
For each screen be able to check all.
Be able to import and export.

= 1.0.1 =
bug fix : Parse error

= 1.0 =
This is the initial release.

== Upgrade Notice ==

= 1.0 =

== 日本語でのご説明 ==

このプラグインは、表示オプションとヘルプタブの非表示設定ができます。
ダッシュボード以外にも、投稿やカテゴリ、固定ページなどの
ページの表示オプションとヘルプの表示設定が可能です。